UNDANGAN DIGITAL EDO & MIFTAHUL

ISI FOLDER
- index.html: kode utama undangan
- images/: tempat menyimpan foto
- music/: tempat menyimpan musik instrumental

CARA MENAMBAHKAN FOTO
Masukkan foto milik Anda ke folder images dengan nama persis:
- cover.jpg       (foto sampul/background)
- edo.jpg         (foto Edo)
- miftahul.jpg    (foto Miftahul)
- foto-1.jpg
- foto-2.jpg
- foto-3.jpg
- foto-4.jpg      (foto slideshow dan galeri)

Gunakan JPG/JPEG dengan ukuran yang tidak terlalu besar agar cepat dibuka di HP.
Jika belum ada foto, halaman tetap tampil tetapi gambar akan kosong pada bagian galeri.

CARA MENAMBAHKAN MUSIK
Masukkan file musik instrumental MP3 yang Anda miliki/berhak gunakan ke:
music/instrumental.mp3
Browser biasanya memblokir autoplay sebelum pengunjung berinteraksi. Musik dicoba diputar setelah tombol “Buka Undangan” ditekan, dan bisa diatur melalui tombol ♫ di pojok kanan bawah.

MAPS
Alamat yang diberikan dimasukkan ke pencarian Google Maps. Pastikan pin yang ditampilkan tepat; bila belum tepat, perbarui tautan dan iframe di index.html dengan tautan lokasi yang benar.

KESAN & PESAN
Versi ini menyimpan ucapan di localStorage browser/perangkat yang digunakan, bukan ke server. Jadi ucapan tidak otomatis terlihat di perangkat lain. Untuk buku tamu online bersama, sambungkan form ke Google Forms, Firebase, Supabase, atau backend milik Anda.

AMPL0P DIGITAL
Amplop animasi sudah aktif. Untuk menampilkan rekening/dompet digital, cari teks `id="paymentInfo"` pada index.html lalu ganti isinya dengan informasi yang memang ingin dipublikasikan.

MENJALANKAN
Buka index.html di browser untuk pratinjau. Untuk menerbitkan gratis, unggah semua isi folder ke repository GitHub lalu aktifkan Settings > Pages > Deploy from a branch, pilih branch main dan folder /(root).
